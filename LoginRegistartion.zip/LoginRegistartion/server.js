const express = require("express")
const path = require("path")
var bcrypt = require('bcrypt');  
 

const app = express()

const PORT = 8000
var bodyParser = require('body-parser');
// use it!
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(path.join(__dirname, "./client")))
app.use(express.static(path.join(__dirname, "./client/static")))

// app.HTTP_VERB('URL', function (req, res){});  // HTTP_VERB is either 'get' or 'post' etc...
app.set("views", path.join(__dirname, "./client/views"))
app.set("view engine", "ejs")

var session = require('express-session')

app.use(session({secret:'secretlogin'}));

require('./server/config/mongoose.js');
var routes_setter = require('./server/config/routes.js');
routes_setter(app)
app.listen(PORT, () => {
	console.log(`Listening on port ${PORT}`)
})
