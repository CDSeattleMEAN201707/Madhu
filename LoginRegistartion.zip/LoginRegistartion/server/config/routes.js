
var users = require('../controllers/users.js');
var mongoose = require('mongoose');
var User = mongoose.model('User');
module.exports = function(app) {
    
app.get("/", (request, response) => {
	 
  response.render('index',{errors:"", passMatch:"",currreg:" "})
 
})

app.get("/homepage", (req, response) => {
    if ( 'name'  in req.session){
        
   response.render('homepage',{'name':req.session.name})}
   else{
     response.redirect('/')

   }
})


app.get("/logout", (req, response) => {
  users.logout(req,response)
})
 
 
app.post('/register', function (req, res){
users.create(req,res)
 });

 app.get('/login', function (req, res){
  res.render('login',{errors:"",currinfo:" "})
 
 });

 app.post('/login', function (req, res){
users.login(req,res)
 });

}