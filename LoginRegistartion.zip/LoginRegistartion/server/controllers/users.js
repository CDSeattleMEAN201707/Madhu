var mongoose = require('mongoose');
var User = mongoose.model('User');
var bcrypt = require('bcrypt');  

module.exports = {
  logout:function(req, res) {
    req.session.destroy()
    res.redirect('/')
  },
  
  login: function(req, res) {
    if (req.body.emailid.length < 1 || req.body.password.length < 1 )
            {if (req.body.emailid.length > 1)
                    {
                      currinfo={'emailid':req.body.emailid}
                    }
            else{
                      currinfo={}
                  }
            res.render('login',{errors:"Please enter email id and password",currinfo:currinfo})
            }
 
    else{
              currinfo={'emailid':req.body.emailid}
              console.log(currinfo)
    }
    curruser=User.findOne({emailid:req.body.emailid},function(err, user){
       
     if (err){
       
              res.render('login',{errors:err,currinfo:currinfo})
    }
     else{
       if(user!=null){
                console.log(user);
                if (bcrypt.compareSync(req.body.password, user.password)){
                      req.session.name = user.name.full;
                      res.redirect('/homepage');
                    }
                else
                  {
                    res.render('login',{errors:"Invalid credentials",currinfo:currinfo})
                  }
              }
        else{
            console.log("PLease register console")
              res.render('login',{errors:"Please Register",currinfo:currinfo})
           }
     }
    }  )
  },
create: function(req, res) {
    currreg={}
    if(req.body.firstname.length >0){
    currreg['firstname']=req.body.firstname
    }
    else{currreg['firstname']=" "}

    if(req.body.lastname.length >0){
    currreg['lastname']=req.body.lastname
    }
    else{currreg['lastname']=""}

    if(req.body.dob.length >0){
    currreg['dob']=req.body.dob
    }
    else{currreg['dob']=""}

    if(req.body.emailid.length >0){
    currreg['emailid']=req.body.emailid
    }
    else{currreg['emailid']=""}

    console.log(currreg)
    
                      
    var newUser = new User({firstname: req.body.firstname,lastname: req.body.lastname, dob: req.body.dob,emailid: req.body.emailid,password:req.body.password});
      if (req.body.password != req.body.passwordconfirm){            
              newUser.validate(function(err){
                    if (err){
                        console.log(err, "in password mismatch")
                        res.render('index', {errors: err, passMatch: true,currreg:currreg})
                    } else {
                        res.render('index', {passMatch: true, errors: "",currreg:currreg})
                    }
                })
                }
      else{
          // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
          console.log('else part of reg'); 
          newUser.save(function(err,user) {
            // if there is an error console.log that something went wrong!
                  if(err) {
                    console.log('creation error', err); 
                    res.render('index', {errors: err,passMatch:false,currreg:currreg})
                  } else { // else console.log that we did well and then redirect to the root route
                    console.log('successfully added a user!');
                    console.log(user.name.full  )
                    
                    req.session.id = user.id;   
                    req.session.name = user.name.full;
                    console.log("session ", req.session.id )
                    res.redirect('/homepage');
                    
                  }
    
        })}


}
  }