const express = require("express")
const path = require("path")
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/basic_mongoose');
var PersonSchema = new mongoose.Schema({
 name: { type: String, required: true, minlength: 1},
 created_at:Date
})

mongoose.model('Person', PersonSchema); 
var Person = mongoose.model('Person') 
const app = express()

const PORT = 8000
var bodyParser = require('body-parser');
// use it!
// app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "./client")))

// app.HTTP_VERB('URL', function (req, res){});  // HTTP_VERB is either 'get' or 'post' etc...
app.set("views", path.join(__dirname, "./client/views"))
app.set("view engine", "ejs")

app.get("/", (request, response) => {
      Person.find({}, function(err, person) {
          response.render("index",{"person":person});
    })
        })

app.get("/:name", (request, response) => {
      Person.findOne({name:request.params.name}, function(err, person) {
          response.render("index",{"person":person});
    })
})

app.get("/remove/:name", (request, response) => {
      Person.remove({name:request.params.name}, function(error) 
          {
            if(error)
            {
              console.log('ERROR!');
              console.log(error);
            }
            console.log('success');
     
          })
          response.redirect('/');
})

 
 
app.get('/new/:name', function (req, res){
  var person = new Person({name: req.params.name});
  // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
  person.save(function(err) {
    // if there is an error console.log that something went wrong!
    if(err) {
      console.log('something went wrong');
      res.render('index', {errors: quote.errors});
    } else { // else console.log that we did well and then redirect to the root route
      console.log('successfully added a person!');
      	 res.redirect('/');
       
    }
  })

     
});

 

     
 


app.listen(PORT, () => {
	console.log(`Listening on port ${PORT}`)
})
