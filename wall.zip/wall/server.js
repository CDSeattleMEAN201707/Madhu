const express = require("express")
const path = require("path")
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/basic_mongoose');

var Schema = mongoose.Schema;
var PostmsgSchema = new mongoose.Schema({
 name: { type: String, required: true, minlength: 1},
 posttext: { type: String, required: true, minlength: 1},
 postcmts:[{type:Schema.Types.ObjectId,ref: 'Postcmt'}],
 created_at:Date,
 updated_at:Date
}) 
mongoose.model('Postmsg', PostmsgSchema); // We are setting this Schema in our Models as 'User'
var Postmsg = mongoose.model('Postmsg') 


var PostcmtSchema = new mongoose.Schema({
 commentorname: { type: String, required: true, minlength: 1},
 commenttext: { type: String, required: true, minlength: 1},
 _postmsg: {type: Schema.Types.ObjectId, ref: 'Postmsg'},
 created_at:Date,
 updated_at:Date
}) 
mongoose.model('Postcmt', PostcmtSchema); // We are setting this Schema in our Models as 'User'
var Postcmt = mongoose.model('Postcmt') 


const app = express()

const PORT = 8000
var bodyParser = require('body-parser');
// use it!
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(path.join(__dirname, "./client")))

// app.HTTP_VERB('URL', function (req, res){});  // HTTP_VERB is either 'get' or 'post' etc...
app.set("views", path.join(__dirname, "./client/views"))
app.set("view engine", "ejs")

app.get("/", (request, response) => {
    Postmsg.find({}).populate('postcmts').exec(function(err,postmsg){
            console.log('postmsg get', postmsg)
            response.render('index', {postmsg: postmsg});
        })
   })  
	
 


app.post('/', function (req, res){
  console.log("here",req.body.action)
  if (req.body.action=="postmsg"){
  var postmsg = new Postmsg({name: req.body.name, posttext: req.body.posttext,created_at:Date(),updated_at:Date() });
  // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
            postmsg.save(function(err) {
                // if there is an error console.log that something went wrong!
                        if(err) {
                        // console.log('something went wrong');
                        res.render('index', {errors: postmsg.errors});
                        } else { // else console.log that we did well and then redirect to the root route
                        // console.log('successfully added a quote!');
                            res.redirect('/');
                        
                        }
            })}


  else if (req.body.action=="postcmt"){
    Postmsg.findOne({_id: req.body.msgid}, function(err, postmsg){
          console.log('before push ', postmsg)
          var postcmt = new Postcmt({commentorname: req.body.commentorname,   commenttext: req.body.commenttext,created_at:Date(),updated_at:Date() });
          console.log('postcmt',postcmt)
          postcmt._postmsg=postmsg._id;
          console.log("interest",postmsg._id)
          postmsg.postcmts.push(postcmt)
            console.log('after push ', postmsg)
              postcmt.save(function(err){
                                if(err) {
                                    console.log('Error in postcmt save');
                              } else {
                                   
                                            postmsg.save(function(err){
                                            if(err) {
                                                    console.log('Error in postmsg save');
                                            } else {
                                                console.log('postmsg',postmsg)
                                                    res.redirect('/');
                                            }
                                                     });
                              }
              })
    })
}
})
 

 app.listen(PORT, () => {
	console.log(`Listening on port ${PORT}`)
})
