const express = require("express")
const path = require("path")
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/basic_mongoose');
var QuoteSchema = new mongoose.Schema({
 name: { type: String, required: true, minlength: 6},
 quotetext: { type: String, required: true, minlength: 6},
 created_at:Date
})
    // QuoteSchema.path('name').required(true, 'Name cannot be blank');
    // QuoteSchema.path('quotetext').required(true, 'quotetext cannot be blank');

mongoose.model('Quote', QuoteSchema); // We are setting this Schema in our Models as 'User'
var Quote = mongoose.model('Quote') 
const app = express()

const PORT = 8000
var bodyParser = require('body-parser');
// use it!
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(path.join(__dirname, "./client")))

// app.HTTP_VERB('URL', function (req, res){});  // HTTP_VERB is either 'get' or 'post' etc...
app.set("views", path.join(__dirname, "./client/views"))
app.set("view engine", "ejs")

app.get("/", (request, response) => {
	 
	response.render("index")
})
 

app.get("/quotes/:id/edit", (request, response) => {
      console.log('the quote id requested is:', request.params.id);
      Quote.find({_id: request.params.id}, function(error, quote) 
          {
            if(error)
            {
              console.log('ERROR!');
              console.log(error);
            }
            console.log(quote);
            response.render('editquote', {quote: quote});
          })
    //console.log(quote);
	
})

app.get("/showuser/:name", (request, response) => {
      console.log('the quote id requested is:', request.params.name);
      Quote.find({name: request.params.name}, function(error, quote) 
          {
            if(error)
            {
              console.log('ERROR!');
              console.log(error);
            }
            else{
            Quote.count({name: request.params.name}, function(err, c) {
                console.log('Count is ' + c);
                response.render('showuser', {name:request.params.name,quote: quote,count:c});
            })
            
            }
          })
    //console.log(quote);
	
})

app.get("/quotes/:id/delete", (request, response) => {
      console.log('the quote id requested is:', request.params.id);
      Quote.remove({_id: request.params.id}, function(error) 
          {
            if(error)
            {
              console.log('ERROR!');
              console.log(error);
            }
            console.log('success');
     
          })
    //console.log(quote);
    response.redirect('/showquotes');
	
})



app.post("/updtquote/:id", function (req, res){
  console.log("update logic")
      Quote.findOne({_id:req.params.id}, function(err, quote) {
        quote.quotetext = req.body.quotetext
      // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
          quote.save(function(err) {
            // if there is an error console.log that something went wrong!
                  if(err) {
                    console.log('something went wrong');
                  } else { // else console.log that we did well and then redirect to the root route
                    console.log('successfully updated a quote!', quote);
                    
                  }
          })
      })
	 res.redirect('/showquotes');
     
});
app.get("/showquotes", (request, response) => {
      Quote.find({}, function(err, quote) {
          response.render("showquotes",{"quote":quote});
    })
    //console.log(quote);
	
})
// app.get("/results/:id", function (req, res){
//     console.log("The user id requested is:", req.params.id);
//     // just to illustrate that req.params is usable here:
//     res.send("You requested the user with id: " + req.params.id);
//     // code to get user from db goes here, etc...
// });
app.post('/addquote', function (req, res){
 

  var quote = new Quote({name: req.body.name, quotetext: req.body.quotetext,created_at:Date() });
  // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
  quote.save(function(err) {
    // if there is an error console.log that something went wrong!
    if(err) {
      console.log('something went wrong');
      res.render('index', {errors: quote.errors});
    } else { // else console.log that we did well and then redirect to the root route
      console.log('successfully added a quote!');
      	 res.redirect('/showquotes');
       
    }
  })

     
});

app.listen(PORT, () => {
	console.log(`Listening on port ${PORT}`)
})
